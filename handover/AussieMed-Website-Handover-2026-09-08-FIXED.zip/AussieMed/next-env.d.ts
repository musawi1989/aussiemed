/// <reference types="next" />
/// <reference types="next/image-types/global" />
// Next.js regenerates local route references on startup.
