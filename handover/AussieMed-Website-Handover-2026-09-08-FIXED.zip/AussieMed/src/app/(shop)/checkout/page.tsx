import type { Metadata } from "next";
import { CheckoutView } from "./CheckoutView";
import {
  accountBranches,
  accountIdentity,
  accountSession,
  accountStaff,
} from "@/lib/account";

export const metadata: Metadata = {
  title: "Checkout",
  description:
    "Confirm your AussieMed trade order: delivery details, purchase order reference and payment terms, with subtotal, VAT and total shown in AED.",
};

/**
 * Checkout.
 *
 * A guest sees the plain form. A signed-in trade account also gets to say
 * which branch the order is for and who is placing it, from lists they keep
 * themselves — both empty for an account that has not set any up, in which
 * case the pickers simply do not appear rather than showing an empty select.
 *
 * EVERYTHING WE ALREADY KNOW IS FILLED IN, AND ALL OF IT STAYS EDITABLE. The
 * account's own details are the fallback beneath the chosen branch, so an
 * account with no branch saved no longer arrives at a blank form and retypes
 * what we are holding. Nothing here is locked: a clinic ordering for a sister
 * site, or having a delivery sent to a different number, types over it.
 */
export default async function CheckoutPage() {
  const session = await accountSession();

  const [branches, staff, identity] = session
    ? await Promise.all([accountBranches(), accountStaff(), accountIdentity()])
    : [[], [], null];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-semibold tracking-tight text-text">
        Checkout
      </h1>
      <CheckoutView
        branches={branches.map((b) => ({
          id: b.id,
          label: b.label ?? b.city,
          line1: b.line1,
          city: b.city,
          contact: b.contact,
          phone: b.phone,
          emirate: b.emirate,
          countryCode: b.countryCode,
          isDefault: b.isDefault,
        }))}
        staff={staff.map((s) => ({ id: s.id, name: s.name }))}
        company={identity?.organisationName ?? ""}
        email={identity?.email ?? ""}
        contactName={identity?.contactName ?? ""}
        phone={identity?.phone ?? ""}
        emirate={identity?.emirate ?? ""}
        countryCode={identity?.countryCode ?? ""}
        // A guest is Prepaid — no account means no credit — and sees the card
        // option priced but not the account terms of somebody else.
        paymentTerms={identity?.paymentTerms ?? "Prepaid"}
        signedIn={Boolean(identity)}
      />
    </div>
  );
}
