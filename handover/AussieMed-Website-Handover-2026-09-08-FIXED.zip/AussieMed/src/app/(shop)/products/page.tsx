import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { FilterPanel } from "@/components/FilterPanel";
import { ViewMore } from "@/components/ViewMore";
import { ProductCard } from "@/components/ProductCard";
import { SortSelect } from "@/components/SortSelect";
import { getAllProducts, getCategoryBySlug, queryProducts, type SortKey } from "@/lib/catalog";
import { departmentsFor } from "@/lib/business-types";
import { emptyMessage, emptyReason } from "@/lib/empty-state";
import { PAGE_SIZE } from "@/lib/query";
import { logSearch } from "@/lib/search-log";
import { currentAgreedPrices } from "@/lib/account-pricing";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

const one = (v: string | string[] | undefined) =>
  Array.isArray(v) ? v[0] : v;

export async function generateMetadata({
  searchParams,
}: {
  searchParams: SearchParams;
}): Promise<Metadata> {
  const params = await searchParams;
  const categorySlug = one(params.category);
  const q = one(params.q);
  const category = categorySlug ? await getCategoryBySlug(categorySlug) : undefined;

  // Unique title and description per filter state — the old site shipped the
  // same title and an empty description on every page.
  if (q) {
    return {
      title: `Search results for “${q}”`,
      description: `Products matching “${q}” at AussieMed — medical, dental and laboratory supplies with volume pricing, priced in AED excluding 5% VAT.`,
    };
  }

  if (category) {
    return {
      title: `${category.name} — Trade Supplies`,
      description: `Buy ${category.name.toLowerCase()} in trade quantities from AussieMed. Volume price breaks on every line, priced in AED excluding 5% VAT, delivered across the UAE.`,
    };
  }

  return {
    title: "All Products — Medical, Dental & Laboratory Supplies",
    description:
      "Browse the full AussieMed catalogue of medical, dental, laboratory and cleaning supplies. Volume pricing on every line, priced in AED excluding 5% VAT.",
  };
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  /*
   * What this account has agreed, if anybody is signed in to one.
   *
   * Empty for a guest, which is what keeps one company's negotiated
   * prices off a page rendered for anybody else.
   */
  const agreed = await currentAgreedPrices();

  const raw = await searchParams;
  const params = {
    category: one(raw.category),
    brand: one(raw.brand),
    q: one(raw.q),
    inStock: one(raw.inStock),
    business: one(raw.business),
    breaks: one(raw.breaks),
    minPrice: one(raw.minPrice),
    maxPrice: one(raw.maxPrice),
    sort: one(raw.sort),
  };

  /**
   * A price off the query string is whatever somebody typed into the address
   * bar. Anything that is not a number is dropped rather than passed on as NaN,
   * which compares false against everything and empties the page.
   */
  const price = (value: string | undefined) => {
    if (value === undefined || value.trim() === "") return undefined;
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : undefined;
  };

  // How many to show, not which page. Everything already seen stays on
  // screen, so this only ever grows.
  const show = Math.max(
    PAGE_SIZE,
    Number.parseInt(one(raw.show) ?? "", 10) || PAGE_SIZE
  );

  const result = await queryProducts({
    groupFamilies: true,
    categorySlug: params.category,
    brand: params.brand,
    q: params.q,
    // Stock never narrows the shop. Honouring ?inStock=1 would let anyone
    // work out what we hold by comparing two result counts — see
    // ProductBadges. The capability stays in query.ts for staff use.
    inStockOnly: false,
    minPriceAED: price(params.minPrice),
    maxPriceAED: price(params.maxPrice),
    withBreaksOnly: params.breaks === "1",
    anyOfCategorySlugs: departmentsFor(params.business),
    sort: (params.sort as SortKey) ?? "relevance",
    offset: 0,
    limit: show,
  });

  // Recorded here rather than in the search box, because this is the only
  // place that knows how many results the term actually found — and a term
  // that found nothing is the whole point of keeping them. Deliberately not
  // awaited into the render path beyond this: it never throws, and a search
  // that fails to log still shows its results. See BE-32.
  await logSearch({
    term: params.q,
    resultCount: result.total,
    categoryScope: params.category ?? null,
  });

  const category = params.category
    ? await getCategoryBySlug(params.category)
    : undefined;
  const heading = category?.name ?? (params.q ? `Results for “${params.q}”` : "All products");

  const hasMore = result.items.length < result.total;

  // Why the list is empty decides what the page says. A category the site
  // advertises but does not stock yet is a different situation from filters
  // narrowed to nothing, and telling the first buyer to clear filters they
  // never set is how an empty page reads as broken. See DEC-27.
  const nothing =
    result.total === 0
      ? emptyMessage(
          emptyReason({
            category: params.category,
            q: params.q,
            brand: params.brand,
            // A price window or a breaks-only tick is narrowing just as much as
            // a brand is, so an empty result reads as over-filtering rather
            // than as a category nobody has stocked.
            inStock:
              params.breaks === "1" ||
              Boolean(params.business) ||
              Boolean(params.minPrice) ||
              Boolean(params.maxPrice),
          }),
          { categoryName: category?.name, q: params.q }
        )
      : null;

  /*
   * The other sizes of each product, so a card can swap between them without
   * navigating away from the grid.
   *
   * Built from the results already on this page rather than fetched: every
   * member of a family is its own card in the same grid, so the objects are
   * here anyway and this is a reference to them.
   *
   * A family whose other members are filtered out of the current results is
   * left alone — the picker hides itself below two members, so a card cannot
   * offer a size the shopper's own filters have excluded.
   */
  const byFamily = new Map<string, typeof result.items>();
  for (const item of await getAllProducts()) {
    if (!item.variantGroup) continue;
    const list = byFamily.get(item.variantGroup);
    if (list) list.push(item);
    else byFamily.set(item.variantGroup, [item]);
  }
  const familyOf = (item: (typeof result.items)[number]) =>
    item.variantGroup ? byFamily.get(item.variantGroup) : undefined;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <nav aria-label="Breadcrumb" className="mb-4 text-sm text-text-muted">
        <ol className="flex flex-wrap items-center gap-1.5">
          <li>
            <Link href="/" className="hover:text-brand">
              Home
            </Link>
          </li>
          <li aria-hidden="true">/</li>
          <li>
            <Link href="/products" className="hover:text-brand">
              Products
            </Link>
          </li>
          {category && (
            <>
              <li aria-hidden="true">/</li>
              <li className="text-text">{category.name}</li>
            </>
          )}
        </ol>
      </nav>

      {/* The title carries the page, so it is set like one. It used to be 24px
          over rows of 14px, which made the name of a department smaller than
          the products inside it. Air as well as size: a heading crowded against
          a breadcrumb is still crowded however large it is set. */}
      <div className="mt-2 flex flex-wrap items-end justify-between gap-3 border-b border-border-base pb-6">
        <div>
          <h1 className="text-4xl font-semibold tracking-tight text-text">
            {heading}
          </h1>
          <p className="mt-2 text-sm text-text-muted tnum">
            {nothing
              ? nothing.title
              : `${result.total} ${result.total === 1 ? "product" : "products"}`}
          </p>
        </div>
        <Suspense fallback={null}>
          <SortSelect value={params.sort ?? "relevance"} />
        </Suspense>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[16rem_1fr]">
        {/* No framing here: the filter carries its own box and its own
            scrolling, so every view it appears on gets the same one. */}
        <aside className="lg:self-start">
          <FilterPanel
            params={params}
            facetCounts={result.facetCounts}
            brands={result.brands}
          />
        </aside>

        <div>
          {nothing ? (
            <div className="rounded-panel border border-border-base bg-surface p-10 text-center">
              <h2 className="text-lg font-semibold text-text">{nothing.title}</h2>
              <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-text-muted">
                {nothing.body}
              </p>
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                {nothing.primary && (
                  <Link
                    href={nothing.primary.href}
                    className="inline-block rounded-card bg-brand px-5 py-2.5 text-sm font-medium text-on-brand transition-colors hover:bg-brand-hover"
                  >
                    {nothing.primary.label}
                  </Link>
                )}
                {nothing.secondary && (
                  <Link
                    href={nothing.secondary.href}
                    className="text-sm font-medium text-brand hover:underline"
                  >
                    {nothing.secondary.label}
                  </Link>
                )}
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-4">
                {result.items.map((product) => (
                  <ProductCard
                    key={`${product.slug}:${product.defaultPackId}`}
                    product={product}
                    agreed={agreed}
                    siblings={familyOf(product)}
                  />
                ))}
              </div>
              <div className="mt-8">
                <ViewMore
                  shown={result.items.length}
                  total={result.total}
                  hasMore={hasMore}
                  nextHref={`?${new URLSearchParams({
                    ...Object.fromEntries(
                      Object.entries(params).filter(([, v]) => Boolean(v)) as [
                        string,
                        string,
                      ][]
                    ),
                    show: String(show + PAGE_SIZE),
                  }).toString()}`}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
