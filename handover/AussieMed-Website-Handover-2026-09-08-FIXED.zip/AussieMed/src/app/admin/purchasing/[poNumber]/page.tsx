import { ProductThumbnail } from "@/components/ProductThumbnail";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { formatAED } from "@/lib/money";
import { StatusPill } from "@/components/StatusPill";
import { PurchaseOrderPayment } from "@/components/admin/PurchaseOrderPayment";
import { PaymentLedger } from "@/components/admin/PaymentLedger";
import { paymentStatusOf } from "@/lib/status-tone";
import { CancelDraftButton, SendButton } from "@/components/admin/PurchasingControls";
import { LineQuantities } from "@/components/admin/LineQuantities";
import { GoodsInForm } from "@/components/admin/GoodsInForm";
import { RecordDocket } from "@/components/admin/RecordDocket";
import { docketPlan } from "@/lib/dockets";
import { courierOptions } from "@/lib/couriers";
import { historyOf } from "@/lib/status-events";
import { humanDuration, stages, timeBetween } from "@/lib/lifecycle";

const aed = (fils: number) => formatAED(fils / 100);
const dubai = (d: Date) =>
  new Date(d.getTime() + 4 * 3_600_000).toISOString().slice(0, 16).replace("T", " ");

/**
 * One purchase order, as the supplier will see it — BE-36.
 *
 * Read this page as the acceptance test for SEC-05: there is nothing on it
 * about who ordered any of it. The allocations exist, and are what will match
 * received goods to the clinics waiting for them, but they live on our side of
 * the wall and are never rendered here.
 */
export default async function PurchaseOrderPage({
  params,
}: {
  params: Promise<{ poNumber: string }>;
}) {
  const { poNumber } = await params;

  const po = await db.purchaseOrder.findUnique({
    where: { poNumber: decodeURIComponent(poNumber) },
    include: {
      payments: { orderBy: [{ occurredAt: "asc" }, { recordedAt: "asc" }] },
      supplier: {
        select: {
          id: true,
          companyName: true,
          primaryEmail: true,
          secondaryEmail: true,
          promisedLeadTimeDays: true,
          ackSlaHours: true,
        },
      },
      lines: { orderBy: { skuCodeSnapshot: "asc" } },
    },
  });

  if (!po) notFound();

  // What has been sent in consignments and what is still owed. Loaded after
  // the guard, so a purchase order that does not exist costs one query rather
  // than three.
  const [plan, couriers] = await Promise.all([
    docketPlan(po.id),
    courierOptions(po.courier),
  ]);

  // Read separately from the order itself: the log outlives what it describes,
  // and a cancelled draft still has a history worth seeing.
  const history = await historyOf("PurchaseOrder", po.id);
  const ackMs = timeBetween(history, "Sent", "Acknowledged");

  const units = po.lines.reduce((n, l) => n + l.qtyOrdered, 0);
  // Null, not zero: a line with no recorded cost used to be stored as costing
  // nothing, which read as a real price everywhere downstream.
  const costsKnown = po.lines.every((l) => l.unitCostFilsSnapshot !== null);

  return (
    <>
      <div className="mt-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link
            href="/admin/purchasing"
            className="inline-flex min-h-11 items-center gap-2 rounded-card border-2 border-navy bg-navy px-4 py-2 font-bold text-white text-sm"
          >
            &larr; All purchase orders
          </Link>
          <h1 className="mt-1 flex flex-wrap items-center gap-2 text-2xl font-bold tracking-tight tnum text-text">
            {po.poNumber}
            <StatusPill axis="fulfilment" status={po.status} />
            {/* Goods and money, side by side. They move independently. */}
            <StatusPill
              axis="payment"
              status={paymentStatusOf(po, new Date())}
            />
          </h1>
          <p className="mt-1 text-sm text-text-muted">
            {po.supplier.companyName} &middot; {po.supplier.primaryEmail}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Not on a draft: a packing list for an order nobody has sent is a
              sheet for a delivery that cannot be coming. The supplier can print
              their own from the portal — this copy is for when they don't. */}
          {po.status !== "Draft" && (
            <Link
              href={`/admin/purchasing/${encodeURIComponent(po.poNumber)}/packing-list`}
              className="rounded-card border border-border-strong bg-surface px-3 py-1.5 text-xs font-bold text-text transition-colors hover:bg-surface-hover"
            >
              Packing list
            </Link>
          )}
          {po.status !== "Draft" && po.status !== "Cancelled" && <SendButton id={po.id} poNumber={po.poNumber} amendment />}
          {po.status === "Draft" && (
            <>
              <SendButton id={po.id} poNumber={po.poNumber} />
              <CancelDraftButton id={po.id} poNumber={po.poNumber} />
            </>
          )}
        </div>
      </div>

      {!costsKnown && (
        <p className="mt-4 rounded-card border-l-4 border-accent-border bg-accent-soft px-4 py-2.5 text-sm font-semibold text-text">
          Some lines have no recorded cost, so the total below is not the real
          value of this order. Costs arrive with the catalogue upload — BE-34.
        </p>
      )}

      <div className="mt-5 grid gap-5 lg:grid-cols-[2fr_1fr]">
        <section className="rounded-card border border-border-base bg-surface p-5 shadow-card">
          <h2 className="text-base font-bold tracking-tight text-text">
            {po.lines.length} line{po.lines.length === 1 ? "" : "s"} &middot;{" "}
            {units} unit{units === 1 ? "" : "s"}
          </h2>
          <p className="mt-1 text-xs text-text-muted">
            Quantities are pooled across every customer who ordered the item
            before the cutoff.
          </p>

          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[34rem] border-collapse text-sm [&_.tnum]:whitespace-nowrap [&_td]:align-top [&_th]:whitespace-nowrap">
              <thead className="border-b border-border-strong text-left text-xs font-bold uppercase tracking-wide text-text-subtle">
                <tr>
                  <th className="py-1.5">Their code</th>
                  <th className="py-1.5">Description</th>
                  <th className="py-1.5 text-right">Qty</th>
                  <th className="py-1.5 text-right">Unit cost</th>
                  <th className="py-1.5 text-right">Line cost</th>
                </tr>
              </thead>
              <tbody>
                {po.lines.map((line) => (
                  <tr key={line.id} className="border-b border-border-base last:border-0">
                    <td className="py-2 tnum font-semibold text-text">
                      {line.supplierPartNumberSnapshot ?? (
                        <span className="text-text-subtle">not recorded</span>
                      )}
                    </td>
                    <td className="py-2 text-text-muted">
                      <ProductThumbnail skuCode={line.skuCodeSnapshot} />{line.nameSnapshot}
                      <span className="block text-xs text-text-subtle tnum">
                        our code {line.skuCodeSnapshot}
                        {line.wasFallback && (
                          <span className="ml-1.5 font-bold text-accent">
                            backup supplier
                          </span>
                        )}
                      </span>
                    </td>
                    <td className="py-2 text-right tnum font-bold text-text">
                      {line.qtyOrdered}
                    </td>
                    <td className="py-2 text-right tnum text-text-muted">
                      {line.unitCostFilsSnapshot === null
                        ? "—"
                        : aed(line.unitCostFilsSnapshot)}
                    </td>
                    <td className="py-2 text-right tnum text-text">
                      {line.lineCostFils === null ? "—" : aed(line.lineCostFils)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={4} className="pt-3 text-right font-bold text-text">
                    Total
                  </td>
                  <td className="pt-3 text-right font-bold tnum text-text">
                    {po.totalCostFils === null ? "—" : aed(po.totalCostFils)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Above Goods in, because it happens first: they tell us what is
              coming, then it arrives. Offered on a draft too, where what we
              ask for is still ours to change. */}
          {po.status !== "Cancelled" && po.status !== "Received" && (
            <LineQuantities
              purchaseOrderId={po.id}
              poNumber={po.poNumber}
              ordersEditable={po.status === "Draft"}
              lines={po.lines.map((line) => ({
                id: line.id,
                name: line.nameSnapshot,
                skuCode: line.skuCodeSnapshot,
                supplierPartNumber: line.supplierPartNumberSnapshot,
                qtyOrdered: line.qtyOrdered,
                qtyConfirmed: line.qtyConfirmed,
              }))}
            />
          )}

          {po.status !== "Draft" && po.status !== "Cancelled" && (
            <div className="mt-5 border-t border-border-base pt-4">
              <h3 className="text-sm font-bold text-text">Goods in</h3>
              <p className="mt-1 text-xs text-text-muted">
                Record what physically arrived. Batch and expiry are per line,
                because one delivery can carry two lots — and a recall answered
                with the wrong lot is worse than one answered with none.
              </p>
              <GoodsInForm
                purchaseOrderId={po.id}
                poNumber={po.poNumber}
                lines={po.lines.map((line) => ({
                  id: line.id,
                  name: line.nameSnapshot,
                  skuCode: line.skuCodeSnapshot,
                  supplierPartNumber: line.supplierPartNumberSnapshot,
                  qtyOrdered: line.qtyOrdered,
                  qtyReceived: line.qtyReceived,
                }))}
              />
            </div>
          )}

          {/* Consignments, between what was ordered and what arrived — which
              is where they sit in real life too. Hidden on a draft: nothing
              can have been sent against an order the supplier has not seen. */}
          {po.status !== "Draft" && plan && (
            <RecordDocket
              id={po.id}
              poNumber={po.poNumber}
              complete={plan.complete}
              dockets={plan.dockets}
              courier={po.courier}
              courierOptions={couriers}
              trackingNumber={po.trackingNumber}
              outstanding={plan.lines
                .filter((line) => line.outstanding > 0)
                .map((line) => ({
                  id: line.id,
                  code: line.skuCode,
                  name: line.name,
                  qtyOrdered: line.qtyOrdered,
                  outstanding: line.outstanding,
                  suggested: line.suggested,
                }))}
            />
          )}
        </section>

        <div className="space-y-5">
          <section className="rounded-card border border-border-base bg-surface p-5 shadow-card">
            <h2 className="text-base font-bold tracking-tight text-text">
              Supplier
            </h2>
            <dl className="mt-3 space-y-1.5 text-sm">
              <Row label="Company" value={po.supplier.companyName} />
              <Row label="Orders to" value={po.supplier.primaryEmail} />
              <Row label="Copy to" value={po.supplier.secondaryEmail} />
              <Row
                label="Promised lead time"
                value={
                  po.supplier.promisedLeadTimeDays
                    ? `${po.supplier.promisedLeadTimeDays} days`
                    : "not agreed"
                }
                warn={!po.supplier.promisedLeadTimeDays}
              />
            </dl>
          </section>

          <section className="rounded-card border border-border-base bg-surface p-5 shadow-card">
            <h2 className="text-base font-bold tracking-tight text-text">
              Dates
            </h2>
            <dl className="mt-3 space-y-1.5 text-sm">
              <Row label="Cutoff" value={dubai(po.cutoffAt)} />
              <Row label="Built" value={dubai(po.createdAt)} />
              <Row label="Sent" value={po.sentAt ? dubai(po.sentAt) : "—"} />
              <Row
                label="Acknowledged"
                value={po.acknowledgedAt ? dubai(po.acknowledgedAt) : "—"}
              />
              <Row
                label="Received"
                value={po.receivedAt ? dubai(po.receivedAt) : "—"}
              />
            </dl>
            <p className="mt-3 text-xs leading-relaxed text-text-subtle">
              All times Dubai.
            </p>
          </section>

          {/* How long each stage actually took — BE-30. The dates above say
              when; this says how long, which is the question asked of a
              supplier. Empty until an order has moved at least once. */}
          {history.length > 0 && (
            <section className="rounded-card border border-border-base bg-surface p-5 shadow-card">
              <h2 className="text-base font-bold tracking-tight text-text">
                How long each stage took
              </h2>
              <ol className="mt-3 space-y-2">
                {stages(history, Date.now()).map((stage, i) => (
                  <li
                    key={`${stage.status}-${stage.enteredAt}`}
                    className="flex flex-wrap items-baseline justify-between gap-2 border-b border-border-base pb-2 last:border-0 last:pb-0"
                  >
                    <span className="text-sm font-bold text-text">
                      {stage.status}
                      {history[i]?.actorName && (
                        <span className="ml-2 text-xs font-normal text-text-subtle">
                          {history[i].actorRole === "Supplier"
                            ? "by the supplier"
                            : `by ${history[i].actorName}`}
                        </span>
                      )}
                    </span>
                    <span
                      className={`text-sm tnum ${
                        stage.leftAt === null
                          ? "font-bold text-accent"
                          : "text-text-muted"
                      }`}
                    >
                      {humanDuration(stage.ms)}
                      {stage.leftAt === null ? " so far" : ""}
                    </span>
                  </li>
                ))}
              </ol>

              {ackMs !== null && (
                <p className="mt-3 rounded-card border-l-4 border-navy-border bg-navy-soft px-3 py-2 text-sm text-text">
                  Acknowledged {humanDuration(ackMs)} after it was sent
                  {po.supplier.ackSlaHours
                    ? ackMs <= po.supplier.ackSlaHours * 3_600_000
                      ? ` — inside their ${po.supplier.ackSlaHours}-hour window.`
                      : ` — outside their ${po.supplier.ackSlaHours}-hour window.`
                    : "."}
                </p>
              )}
            </section>
          )}

          {/* Money out. Below the goods rather than beside them, because
              receiving is the job somebody usually came here to do and paying
              is the one they come back for. */}
          <PaymentLedger entity="PurchaseOrder" id={po.id} entries={po.payments} />
          <PurchaseOrderPayment
            id={po.id}
            paymentStatus={po.paymentStatus}
            derivedStatus={paymentStatusOf(po, new Date())}
            paidAED={aed(po.paidFils)}
            totalAED={po.totalCostFils === null ? "—" : aed(po.totalCostFils)}
            paymentDueOn={
              po.paymentDueOn
                ? dubai(po.paymentDueOn).slice(0, 10)
                : ""
            }
          />
        </div>
      </div>
    </>
  );
}

function Row({
  label,
  value,
  warn = false,
}: {
  label: string;
  value: string;
  warn?: boolean;
}) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-text-muted">{label}</dt>
      <dd className={`text-right tnum ${warn ? "font-bold text-danger" : "text-text"}`}>
        {value}
      </dd>
    </div>
  );
}
