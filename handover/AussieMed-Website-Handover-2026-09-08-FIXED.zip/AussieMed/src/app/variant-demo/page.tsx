"use client";

import { useState } from "react";

/* ===========================================================================
 * DEMO ONLY — not part of the site.
 *
 * Not linked from any navigation, not committed (see .gitignore), and it
 * touches no real data. Delete the folder to remove it.
 *
 * It shows how one product sells in several colours and sizes WITHOUT
 * creating a separate product per combination — the ProductOption /
 * ProductOptionValue / SkuOptionValue models that already exist in
 * prisma/schema.prisma but are not yet wired to the storefront (FN-07).
 * ======================================================================== */

/** A sellable combination. One row here = one ProductSku in the real schema. */
type Sku = {
  code: string;
  colour: string;
  size: string;
  /** Money is integer fils everywhere. Never a float. */
  priceFils: number;
  outOfStock?: boolean;
};

const COLOURS = [
  { value: "Blue", hex: "#2f5fd0", ink: "#ffffff" },
  { value: "Black", hex: "#1f1f1f", ink: "#ffffff" },
  { value: "Cream", hex: "#e6dac2", ink: "#3b3121" },
];

const SIZES = ["XS", "S", "M", "L", "XL"];

/**
 * The matrix is deliberately SPARSE — 12 rows, not 15.
 *
 * Cream is not made in XS or XL, and Black has no XS. This is the case a naive
 * "colour dropdown x size dropdown" gets wrong: it offers combinations that
 * cannot be bought. Availability is a property of the data, so the picker has
 * to read it rather than assume a full grid.
 */
const SKUS: Sku[] = [
  { code: "NT-NIT-BL-XS", colour: "Blue", size: "XS", priceFils: 3450 },
  { code: "NT-NIT-BL-S", colour: "Blue", size: "S", priceFils: 3450 },
  { code: "NT-NIT-BL-M", colour: "Blue", size: "M", priceFils: 3450 },
  { code: "NT-NIT-BL-L", colour: "Blue", size: "L", priceFils: 3600 },
  { code: "NT-NIT-BL-XL", colour: "Blue", size: "XL", priceFils: 3850 },

  { code: "NT-NIT-BK-S", colour: "Black", size: "S", priceFils: 4100 },
  { code: "NT-NIT-BK-M", colour: "Black", size: "M", priceFils: 4100 },
  {
    code: "NT-NIT-BK-L",
    colour: "Black",
    size: "L",
    priceFils: 4250,
    outOfStock: true,
  },
  { code: "NT-NIT-BK-XL", colour: "Black", size: "XL", priceFils: 4500 },

  { code: "NT-NIT-CR-S", colour: "Cream", size: "S", priceFils: 3300 },
  { code: "NT-NIT-CR-M", colour: "Cream", size: "M", priceFils: 3300 },
  { code: "NT-NIT-CR-L", colour: "Cream", size: "L", priceFils: 3400 },
];

/** Volume breaks, in the same shape the real BuyBox shows. */
const TIERS = [
  { qty: 1, unit: "EACH", factor: 1 },
  { qty: 12, unit: "CARTON", factor: 0.96 },
  { qty: 48, unit: "BOX", factor: 0.92 },
];

/** House rule: always the English string AED, always exactly 2 decimals. */
function aed(fils: number) {
  return "AED " + (fils / 100).toFixed(2);
}

function findSku(colour: string, size: string) {
  return SKUS.find((s) => s.colour === colour && s.size === size);
}

export default function VariantDemoPage() {
  const [colour, setColour] = useState("Blue");
  const [size, setSize] = useState("M");
  const [qty, setQty] = useState(1);

  const sku = findSku(colour, size);
  const swatch = COLOURS.find((c) => c.value === colour);

  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <div className="mb-8 rounded-panel border border-accent-border bg-accent-soft px-4 py-3 text-sm">
        <strong>Demo page — not part of the site.</strong> Nothing here is
        committed or linked. It illustrates one product sold in many colours and
        sizes, using option models that already exist in the schema.
      </div>

      <p className="text-xs font-bold uppercase tracking-wide text-text-muted">
        NI-TEK · Examination Gloves
      </p>
      <h1 className="mt-1 font-display text-3xl font-bold text-text">
        Ni-Tek Nitrile Premium Examination Gloves
      </h1>
      <p className="mt-2 max-w-2xl text-sm text-text-muted">
        Powder free, EN374, HACCP grade, 100 per box. One product. Twelve
        sellable combinations. No duplicated listings.
      </p>

      <div className="mt-8 grid gap-8 md:grid-cols-2">
        {/* ---------------- Image, tinted by the chosen colour ------------- */}
        <div>
          <div
            className="flex aspect-square items-center justify-center rounded-panel border border-border-base"
            style={{ backgroundColor: swatch?.hex }}
          >
            <span
              className="font-display text-2xl font-bold opacity-90"
              style={{ color: swatch?.ink }}
            >
              {colour} · {size}
            </span>
          </div>
          <p className="mt-2 text-xs text-text-muted">
            In the real model this is ProductImage.skuId — an image attached to
            one SKU, so choosing Black shows the black glove.
          </p>
        </div>

        {/* ---------------- The picker ------------------------------------ */}
        <div>
          {/* Colour axis — ProductOption "Colour" */}
          <fieldset>
            <legend className="mb-2 text-sm font-bold text-text">
              Colour
              <span className="ml-1 font-normal text-text-muted">
                ({COLOURS.length} available)
              </span>
            </legend>
            <div className="flex gap-2">
              {COLOURS.map((c) => {
                const active = c.value === colour;
                return (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => setColour(c.value)}
                    aria-pressed={active}
                    className={`flex items-center gap-2 rounded-card border px-3 py-2 text-sm font-semibold transition ${
                      active
                        ? "border-navy bg-navy-soft text-navy"
                        : "border-border-strong bg-surface text-text hover:bg-surface-hover"
                    }`}
                  >
                    <span
                      className="h-4 w-4 rounded-full border border-border-strong"
                      style={{ backgroundColor: c.hex }}
                    />
                    {c.value}
                  </button>
                );
              })}
            </div>
          </fieldset>

          {/* Size axis — ProductOption "Size" */}
          <fieldset className="mt-5">
            <legend className="mb-2 text-sm font-bold text-text">Size</legend>
            <div className="flex flex-wrap gap-2">
              {SIZES.map((s) => {
                const exists = Boolean(findSku(colour, s));
                const active = s === size;
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSize(s)}
                    disabled={!exists}
                    aria-pressed={active}
                    title={exists ? undefined : `Not made in ${colour}`}
                    className={`min-w-14 rounded-card border px-3 py-2 text-sm font-semibold transition ${
                      !exists
                        ? "cursor-not-allowed border-border-base bg-surface-sunken text-text-subtle line-through"
                        : active
                          ? "border-navy bg-navy-soft text-navy"
                          : "border-border-strong bg-surface text-text hover:bg-surface-hover"
                    }`}
                  >
                    {s}
                  </button>
                );
              })}
            </div>
            <p className="mt-2 text-xs text-text-muted">
              Struck-through sizes are not made in {colour}. The grid is sparse
              — 12 real combinations out of a possible 15.
            </p>
          </fieldset>

          {/* ---------------- The resolved SKU ---------------------------- */}
          <div className="mt-6 rounded-panel border border-border-base bg-surface-sunken p-4">
            {!sku ? (
              <p className="text-sm font-semibold text-danger">
                That combination is not sold.
              </p>
            ) : (
              <>
                <div className="flex items-baseline justify-between">
                  <span className="text-xs font-bold uppercase tracking-wide text-text-muted">
                    {sku.code}
                  </span>
                  {sku.outOfStock ? (
                    <span className="rounded-card bg-danger-soft px-2 py-0.5 text-xs font-bold text-danger">
                      Out of stock
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-success">
                      In stock
                    </span>
                  )}
                </div>

                <p className="mt-2 font-display text-2xl font-bold text-text">
                  {aed(sku.priceFils)}{" "}
                  <span className="text-sm font-normal text-text-muted">
                    per each
                  </span>
                </p>

                <table className="mt-3 w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs uppercase text-text-muted">
                      <th className="font-bold">Quantity</th>
                      <th className="text-right font-bold">Price (ex. VAT)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {TIERS.map((t) => (
                      <tr key={t.qty} className="border-t border-border-base">
                        <td className="py-1">
                          +{t.qty}{" "}
                          <span className="text-text-muted">{t.unit}</span>
                        </td>
                        <td className="py-1 text-right font-semibold">
                          {aed(Math.round(sku.priceFils * t.factor))}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Quantities are integers. Never 3.00. */}
                <div className="mt-4 flex items-center gap-2">
                  <div className="flex h-11 items-center rounded-card border border-border-strong bg-surface">
                    <button
                      type="button"
                      onClick={() => setQty((q) => Math.max(1, q - 1))}
                      className="h-full px-3 text-lg text-text-muted"
                      aria-label="Decrease quantity"
                    >
                      −
                    </button>
                    <input
                      value={qty}
                      inputMode="numeric"
                      onChange={(e) => {
                        const n = parseInt(e.target.value, 10);
                        setQty(Number.isFinite(n) && n > 0 ? n : 1);
                      }}
                      className="h-full w-14 bg-transparent text-center font-semibold text-text outline-none"
                      aria-label="Quantity"
                    />
                    <button
                      type="button"
                      onClick={() => setQty((q) => q + 1)}
                      className="h-full px-3 text-lg text-text-muted"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>
                  <button
                    type="button"
                    disabled={sku.outOfStock}
                    className="h-11 flex-1 rounded-card bg-red px-4 font-bold text-on-red disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {sku.outOfStock ? "Notify me" : "Add to cart"}
                  </button>
                </div>
                <p className="mt-2 text-xs text-text-muted">
                  The cart line stores <strong>{sku.code}</strong> — the SKU, not
                  the product. That is what makes this safe.
                </p>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ---------------- On the category listing ----------------------- */}
      <section className="mt-14 border-t border-border-base pt-8">
        <h2 className="font-display text-xl font-bold text-text">
          On the category listing
        </h2>
        <p className="mt-2 max-w-3xl text-sm text-text-muted">
          This is where the difference is felt. Same product, same category,
          two ways of showing it.
        </p>

        {/* --- Today ---------------------------------------------------- */}
        <h3 className="mt-8 text-sm font-bold uppercase tracking-wide text-text-muted">
          Today — one card per combination
        </h3>
        <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {SKUS.slice(0, 4).map((s) => (
            <LegacyCard key={s.code} sku={s} />
          ))}
        </div>
        <p className="mt-2 text-xs text-text-muted">
          …and eight more, all but identical. The buyer scrolls past twelve
          near-duplicate tiles to find one glove, and the shelf looks padded.
        </p>

        {/* --- With options --------------------------------------------- */}
        <h3 className="mt-10 text-sm font-bold uppercase tracking-wide text-text-muted">
          With options — one card, chosen on the card
        </h3>
        <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <VariantCard />
          <PlainCard
            sku="SAMPLE-BAGS-149-1"
            name="Bags sample product 1"
            price="AED 20.50"
            unit="per each"
          />
          <PlainCard
            sku="TS-1032"
            name="Aqium Antibacterial Hand Sanitiser Ultra 375Ml"
            price="AED 19.34"
            unit="per each"
          />
          <PlainCard
            sku="SAMPLE-BAGS-149-2"
            name="Bags sample product 2"
            price="AED 30.00"
            unit="per box"
          />
        </div>
        <p className="mt-2 text-xs text-text-muted">
          One tile. Colour and size chosen in place, price and SKU updating as
          they change, straight into the cart without opening the product.
          For a trade buyer reordering a known line, that is the whole journey.
        </p>

        <div className="mt-6 rounded-panel border border-accent-border bg-accent-soft px-4 py-3 text-sm">
          <strong>One consequence to decide on.</strong> Your category counts
          change meaning. &ldquo;Gloves 12&rdquo; becomes &ldquo;Gloves
          1&rdquo;, because there is now one product on that shelf. The rule
          that a category&rsquo;s advertised count equals what clicking it
          returns still holds — but the number a buyer sees drops, and the
          business needs to agree that counting listings rather than
          combinations is what they want.
        </div>
      </section>

      {/* ---------------- The explanation ------------------------------- */}
      <section className="mt-12 border-t border-border-base pt-8">
        <h2 className="font-display text-xl font-bold text-text">
          How this is modelled
        </h2>

        <p className="mt-3 max-w-3xl text-sm text-text-muted">
          The important distinction: you still need one row per sellable
          combination, because each has its own stock, price and barcode. What
          you avoid is one <em>product listing</em> per combination. Twelve SKUs
          sit under a single ProductMaster, so the catalogue shows one glove,
          not twelve.
        </p>

        <div className="mt-5 overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-border-strong text-left">
                <th className="py-2 font-bold">Model</th>
                <th className="py-2 font-bold">Holds</th>
                <th className="py-2 font-bold">For this glove</th>
              </tr>
            </thead>
            <tbody className="text-text-muted">
              <tr className="border-b border-border-base">
                <td className="py-2 font-semibold text-text">ProductMaster</td>
                <td className="py-2">The listing a buyer finds</td>
                <td className="py-2">1 — Ni-Tek Nitrile Premium</td>
              </tr>
              <tr className="border-b border-border-base">
                <td className="py-2 font-semibold text-text">ProductOption</td>
                <td className="py-2">An axis</td>
                <td className="py-2">2 — Colour, Size</td>
              </tr>
              <tr className="border-b border-border-base">
                <td className="py-2 font-semibold text-text">
                  ProductOptionValue
                </td>
                <td className="py-2">A value on an axis</td>
                <td className="py-2">8 — Blue/Black/Cream, XS…XL</td>
              </tr>
              <tr className="border-b border-border-base">
                <td className="py-2 font-semibold text-text">ProductSku</td>
                <td className="py-2">
                  A sellable thing: own price, stock, barcode
                </td>
                <td className="py-2">12 — the sparse matrix</td>
              </tr>
              <tr className="border-b border-border-base">
                <td className="py-2 font-semibold text-text">SkuOptionValue</td>
                <td className="py-2">Which values a SKU represents</td>
                <td className="py-2">24 — two per SKU</td>
              </tr>
            </tbody>
          </table>
        </div>

        <h3 className="mt-8 font-display text-lg font-bold text-text">
          Why not just add them as products?
        </h3>
        <p className="mt-2 max-w-3xl text-sm text-text-muted">
          That is what the site does today. The six glove lines in the catalogue
          are six separate ProductMaster rows tied together by{" "}
          <code className="rounded bg-surface-sunken px-1">variantGroup</code>,
          shown to the buyer as the Size / volume dropdown. It works, but every
          combination costs a listing: 3 colours x 5 sizes becomes 15 products to
          describe, photograph, categorise and keep in step. Change the
          description once and you change it fifteen times.
        </p>
        <p className="mt-2 max-w-3xl text-sm text-text-muted">
          Both mechanisms are in the schema on purpose. Use{" "}
          <strong>options</strong> when the buyer thinks &ldquo;same glove,
          different size&rdquo;. Use <strong>variantGroup</strong> when they are
          genuinely different lines a buyer might compare — the 375ml and the
          60ml sanitiser, which have their own photography and their own place on
          a shelf.
        </p>
      </section>
    </main>
  );
}

/* ===========================================================================
 * Grid cards
 *
 * Deliberately close to src/components/ProductCard.tsx — same shell, same
 * type scale, same red Add to cart — so the comparison is about the variant
 * handling and not about styling.
 * ======================================================================== */

const CARD =
  "flex flex-col overflow-hidden rounded-card border border-border-base bg-surface shadow-card";

/** A card for a product with no options. Included only for context. */
function PlainCard({
  sku,
  name,
  price,
  unit,
}: {
  sku: string;
  name: string;
  price: string;
  unit: string;
}) {
  return (
    <article className={CARD}>
      <div className="aspect-[4/3] w-full bg-surface-sunken" />
      <div className="flex flex-1 flex-col gap-2 p-3">
        <p className="text-xs font-bold uppercase tracking-wide text-text-subtle">
          {sku}
        </p>
        <h3 className="text-sm font-medium leading-snug text-text">{name}</h3>
        <div className="mt-auto space-y-2 pt-1">
          <p className="flex items-baseline gap-1.5">
            <span className="text-lg font-bold text-text">{price}</span>
            <span className="text-xs text-text-muted">{unit}</span>
          </p>
          <button
            type="button"
            className="h-9 w-full rounded-card bg-red text-sm font-bold text-on-red"
          >
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}

/**
 * How a combination looks today: its own tile, its own photograph, its own
 * description — repeated twelve times with three words different.
 */
function LegacyCard({ sku }: { sku: Sku }) {
  const swatch = COLOURS.find((c) => c.value === sku.colour);
  return (
    <article className={CARD}>
      <div
        className="flex aspect-[4/3] w-full items-center justify-center"
        style={{ backgroundColor: swatch?.hex }}
      >
        <span
          className="text-xs font-bold opacity-80"
          style={{ color: swatch?.ink }}
        >
          {sku.colour}
        </span>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-3">
        <p className="text-xs font-bold uppercase tracking-wide text-text-subtle">
          {sku.code} · NI-TEK
        </p>
        <h3 className="text-sm font-medium leading-snug text-text">
          Ni-Tek Nitrile Premium Examination Gloves, Powder Free, EN374,{" "}
          {sku.size}, {sku.colour}, 100/Box
        </h3>
        <div className="mt-auto space-y-2 pt-1">
          <p className="flex items-baseline gap-1.5">
            <span className="text-lg font-bold text-text">
              {aed(sku.priceFils)}
            </span>
            <span className="text-xs text-text-muted">per each</span>
          </p>
          <button
            type="button"
            className="h-9 w-full rounded-card bg-red text-sm font-bold text-on-red"
          >
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}

/**
 * The same twelve combinations as one tile.
 *
 * Colour is swatches rather than a dropdown because a colour is a thing you
 * recognise faster than you read. Size stays a dropdown: five values in a card
 * this narrow would wrap, and size is a word the buyer already knows.
 */
function VariantCard() {
  const [colour, setColour] = useState("Blue");
  const [size, setSize] = useState("M");

  const sku = findSku(colour, size);
  const swatch = COLOURS.find((c) => c.value === colour);

  /** Sizes actually made in the chosen colour. */
  const sizesFor = SIZES.filter((s) => findSku(colour, s));

  /**
   * Switching colour can strand the chosen size — Cream has no XL. Fall back
   * to the nearest available size rather than showing an empty card.
   */
  function chooseColour(next: string) {
    setColour(next);
    if (!findSku(next, size)) {
      const fallback = SIZES.find((s) => findSku(next, s));
      if (fallback) setSize(fallback);
    }
  }

  return (
    <article className={`${CARD} ring-2 ring-navy`}>
      <div
        className="relative flex aspect-[4/3] w-full items-center justify-center"
        style={{ backgroundColor: swatch?.hex }}
      >
        <span
          className="text-xs font-bold opacity-80"
          style={{ color: swatch?.ink }}
        >
          {colour} · {size}
        </span>
        <span className="absolute left-2 top-2 rounded-card bg-surface/90 px-1.5 py-0.5 text-[10px] font-bold text-text">
          12 options
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-2 p-3">
        <p className="text-xs font-bold uppercase tracking-wide text-text-subtle">
          {sku?.code} · NI-TEK
        </p>
        <h3 className="text-sm font-medium leading-snug text-text">
          Ni-Tek Nitrile Premium Examination Gloves, Powder Free, EN374,
          100/Box
        </h3>

        {/* Colour — swatches, recognised at a glance. */}
        <div className="flex items-center gap-1.5">
          {COLOURS.map((c) => (
            <button
              key={c.value}
              type="button"
              onClick={() => chooseColour(c.value)}
              aria-label={c.value}
              aria-pressed={c.value === colour}
              title={c.value}
              className={`h-5 w-5 rounded-full border-2 transition ${
                c.value === colour
                  ? "border-navy"
                  : "border-border-strong hover:border-text-muted"
              }`}
              style={{ backgroundColor: c.hex }}
            />
          ))}
          <span className="ml-1 text-[11px] text-text-muted">{colour}</span>
        </div>

        {/* Size — a dropdown, because five buttons would wrap in this width. */}
        <label className="block">
          <span className="mb-1 block text-xs font-bold text-text">
            Size
            <span className="ml-1 font-normal text-text-muted">
              ({sizesFor.length} available)
            </span>
          </span>
          <select
            value={size}
            onChange={(e) => setSize(e.target.value)}
            aria-label="Choose a size"
            className="h-8 w-full rounded-card border border-border-strong bg-surface px-2 text-xs font-semibold text-text"
          >
            {sizesFor.map((s) => {
              const match = findSku(colour, s);
              return (
                <option key={s} value={s}>
                  {s}
                  {match?.outOfStock ? " — out of stock" : ""}
                </option>
              );
            })}
          </select>
        </label>

        <div className="mt-auto space-y-2 pt-1">
          <p className="flex items-baseline gap-1.5">
            <span className="text-lg font-bold text-text">
              {sku ? aed(sku.priceFils) : "—"}
            </span>
            <span className="text-xs text-text-muted">per each</span>
          </p>
          <p className="text-xs font-semibold text-text-muted">100 Pieces/Box</p>

          {sku?.outOfStock ? (
            <button
              type="button"
              className="h-9 w-full rounded-card border border-border-strong bg-surface text-sm font-bold text-text"
            >
              Notify me
            </button>
          ) : (
            <button
              type="button"
              className="h-9 w-full rounded-card bg-red text-sm font-bold text-on-red"
            >
              Add to cart
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
